"""
os_module.py
------------
Translated from OS.f

Full successive-orders-of-scattering radiative transfer (OS subroutine).
This is the more complete version of ISO — it also fills the radiance
field arrays xlm(-mu:mu, np) used by ATMREF.

The implementation delegates to the ISO machinery with the addition of
building the full xlm output.
"""

import math
import numpy as np

from .commons    import delta_sigma, trunc, ier as ier_common
from .scattering import discre
from .kernel     import kernel_func


def os_sos(tamoy, trmoy, pizmoy, tamoyp, trmoyp, palt,
           phirad, nt, mu, np_, rm, gb, rp, xl):
    """
    Successive Orders of Scattering — fills xl(-mu:mu, np) with
    the radiance field.

    Parameters
    ----------
    tamoy, trmoy, pizmoy : float – aerosol OD, Rayleigh OD, SSA
    tamoyp, trmoyp       : float – ODs above plane
    palt                 : float – plane altitude (km; >900 → satellite)
    phirad               : float – relative azimuth (radians)
    nt                   : int   – number of layers
    mu, np_              : int   – Gauss angles, azimuth points
    rm, gb, rp           : arrays – Gauss nodes/weights, azimuth points
    xl                   : 2-D array – output radiance field (-mu:mu, np_)
                           xl is modified in-place.
    """
    delta  = delta_sigma.delta
    betal  = trunc.betal
    _ier   = ier_common

    snt   = nt
    accu  = 1.0e-20
    accu2 = 1.0e-3
    hr    = 8.0

    ta  = tamoy
    tr  = trmoy
    piz = pizmoy
    trp = trmoy  - trmoyp
    tap = tamoy  - tamoyp

    iplane = 0

    if palt <= 900.0 and palt > 0.0:
        ha  = -palt / math.log(tap / ta) if tap > 1.0e-3 else 2.0
        ntp = nt - 1
    else:
        ha  = 2.0
        ntp = nt

    h    = [0.0] * (nt + 2)
    xdel = [0.0] * (nt + 2)
    ydel = [0.0] * (nt + 2)
    altc = [0.0] * (nt + 2)

    if ta <= accu2 and tr > ta:
        for j in range(ntp + 1):
            h[j]    = j * tr / ntp if ntp else 0.0
            ydel[j] = 1.0; xdel[j] = 0.0
            altc[j] = -math.log(h[j] / tr) * hr if j > 0 and h[j] > 0 else 300.0
    elif tr <= accu2 and ta > tr:
        for j in range(ntp + 1):
            h[j]    = j * ta / ntp if ntp else 0.0
            ydel[j] = 0.0; xdel[j] = piz
    else:
        ydel[0] = 1.0; xdel[0] = 0.0; h[0] = 0.0; altc[0] = 300.0
        zx = 300.0
        for it in range(ntp + 1):
            if it == 0:
                yy = 0.0; dd = 0.0
            else:
                yy = h[it - 1]; dd = ydel[it - 1]
            zx = discre(ta, ha, tr, hr, it, ntp, yy, dd, 300.0, 0.0)
            if _ier.ier:
                return
            xxx = -zx / ha
            ca  = ta * math.exp(xxx) if xxx >= -18.0 else 0.0
            cr  = tr * math.exp(-zx / hr)
            h[it]    = cr + ca; altc[it] = zx
            cr2 = cr / hr; ca2 = ca / ha
            ratio = cr2 / (cr2 + ca2)
            xdel[it] = (1.0 - ratio) * piz; ydel[it] = ratio

    # Insert plane layer
    if ntp == nt - 1:
        taup   = tap + trp
        iplane = -1
        for i in range(ntp + 1):
            if taup >= h[i]:
                iplane = i
        th = 0.005
        xt1 = abs(h[iplane] - taup)
        xt2 = abs(h[iplane + 1] - taup) if iplane + 1 <= nt else 1e9
        if xt1 > th and xt2 > th:
            for i in range(nt, iplane, -1):
                xdel[i] = xdel[i - 1]; ydel[i] = ydel[i - 1]
                h[i] = h[i - 1]; altc[i] = altc[i - 1]
        else:
            if xt2 < xt1:
                iplane += 1
        h[iplane] = taup
        if tr > accu2 and ta > accu2:
            ca = ta * math.exp(-palt / ha); cr = tr * math.exp(-palt / hr)
            cr /= hr; ca /= ha; ratio = cr / (cr + ca)
            xdel[iplane] = (1.0 - ratio) * piz; ydel[iplane] = ratio; altc[iplane] = palt
        elif tr > accu2:
            ydel[iplane] = 1.0; xdel[iplane] = 0.0; altc[iplane] = palt
        else:
            ydel[iplane] = 0.0; xdel[iplane] = piz; altc[iplane] = palt

    aaaa  = delta / (2.0 - delta)
    ron   = (1.0 - aaaa) / (1.0 + 2.0 * aaaa)
    beta0 = 1.0; beta2 = 0.5 * ron

    size_j = 2 * mu + 1
    def ji(k): return k + mu

    # Loop over azimuth components
    xl_local = np.zeros((size_j, np_))

    for ip_idx in range(np_):
        is_val = ip_idx   # azimuth harmonic order
        ig_val = 1

        i1   = np.zeros((nt + 1, size_j))
        i2   = np.zeros((nt + 1, size_j))
        i3   = np.zeros(size_j)
        inm1 = np.zeros(size_j)
        inm2 = np.zeros(size_j)
        _in  = np.zeros(size_j)

        tavion0 = tavion1 = tavion2 = tavion = 0.0

        xpl, psl, bp = kernel_func(is_val, mu, rm)

        # Primary upward
        for k in range(1, mu + 1):
            i1[nt, ji(k)] = 1.0 if is_val == 0 else 0.0
            zi1 = i1[nt, ji(k)]
            yy  = rm[ji(k)]
            for i in range(nt - 1, -1, -1):
                if is_val == 0:
                    i1[i, ji(k)] = math.exp(-(ta + tr - h[i]) / yy)
                else:
                    i1[i, ji(k)] = 0.0

        for k in range(-mu, 0):
            for i in range(nt + 1):
                i1[i, ji(k)] = 0.0

        for k in range(-mu, mu + 1):
            idx = nt if k < 0 else 0
            inm1[ji(k)] = i1[idx, ji(k)]
            inm2[ji(k)] = i1[idx, ji(k)]
            i3[ji(k)]   = i1[idx, ji(k)]

        ipl = iplane if iplane >= 0 else 0
        tavion   = i1[ipl, ji(mu)]
        tavion2  = tavion

        while True:
            ig_val += 1
            for k in range(1, mu + 1):
                xpk = xpl[ji(k)]; ypk = xpl[ji(-k)]
                for i in range(nt + 1):
                    ii1 = 0.0; ii2 = 0.0
                    x = xdel[i]; y = ydel[i]
                    for j in range(1, mu + 1):
                        xpj = xpl[ji(j)]; z = gb[ji(j)]
                        xi1 = i1[i, ji(j)]; xi2 = i1[i, ji(-j)]
                        bpjk  = bp[j, ji(k)]  * x + y * (beta0 + beta2 * xpj * xpk)
                        bpjmk = bp[j, ji(-k)] * x + y * (beta0 + beta2 * xpj * ypk)
                        ii2 += z * (xi1 * bpjk  + xi2 * bpjmk)
                        ii1 += z * (xi1 * bpjmk + xi2 * bpjk)
                    i2[i, ji(k)] = ii2; i2[i, ji(-k)] = ii1

            for k in range(1, mu + 1):
                i1[nt, ji(k)] = 0.0; zi1 = 0.0; yy = rm[ji(k)]
                for i in range(nt - 1, -1, -1):
                    jj = i + 1; f = h[jj] - h[i]
                    a = (i2[jj, ji(k)] - i2[i, ji(k)]) / f
                    b = i2[i, ji(k)] - a * h[i]
                    c = math.exp(-f / yy); d = 1.0 - c; xx = h[i] - h[jj] * c
                    zi1 = c * zi1 + (d * (b + a * yy) + a * xx) * 0.5
                    i1[i, ji(k)] = zi1

            for k in range(-mu, 0):
                i1[0, ji(k)] = 0.0; zi1 = 0.0; yy = rm[ji(k)]
                for i in range(1, nt + 1):
                    jj = i - 1; f = h[i] - h[jj]
                    c = math.exp(f / yy); d = 1.0 - c
                    a = (i2[i, ji(k)] - i2[jj, ji(k)]) / f
                    b = i2[i, ji(k)] - a * h[i]; xx = h[i] - h[jj] * c
                    zi1 = c * zi1 + (d * (b + a * yy) + a * xx) * 0.5
                    i1[i, ji(k)] = zi1

            for k in range(-mu, mu + 1):
                idx = nt if k < 0 else 0
                _in[ji(k)] = i1[idx, ji(k)]
            tavion0 = i1[ipl, ji(mu)]

            if ig_val > 2:
                z = 0.0
                a1 = tavion2; d1 = tavion1; g1 = tavion0
                if a1 >= accu and d1 >= accu and tavion >= accu:
                    z = max(z, abs(((g1/d1 - d1/a1) / ((1.0 - g1/d1)**2)) * (g1/tavion)))
                for l in range(-mu, mu + 1):
                    if l == 0: continue
                    a1 = inm2[ji(l)]; d1 = inm1[ji(l)]; g1 = _in[ji(l)]
                    if a1 == 0.0 or d1 == 0.0 or i3[ji(l)] == 0.0: continue
                    z = max(z, abs(((g1/d1 - d1/a1) / ((1.0 - g1/d1)**2)) * (g1/i3[ji(l)])))
                if z < 0.0001:
                    for l in range(-mu, mu + 1):
                        if l == 0: continue
                        d1 = inm1[ji(l)]; g1 = _in[ji(l)]
                        if d1 == 0.0: continue
                        y1 = 1.0 - g1/d1; i3[ji(l)] += g1/y1
                    d1 = tavion1; g1 = tavion0
                    if d1 >= accu and abs(g1 - d1) >= accu:
                        y1 = 1.0 - g1/d1; tavion += g1/y1
                    else:
                        tavion += g1
                    break
                inm2[:] = inm1; tavion2 = tavion1

            inm1[:] = _in; tavion1 = tavion0
            i3 += _in; tavion += tavion0

            z = 0.0
            for l in range(-mu, mu + 1):
                if i3[ji(l)] != 0.0:
                    z = max(z, abs(_in[ji(l)] / i3[ji(l)]))
            if z < 0.00001 or ig_val >= 20:
                break

        # Accumulate azimuth contribution
        coeff_az = 1.0 if ip_idx == 0 else 2.0 * math.cos(ip_idx * phirad)
        for k in range(-mu, mu + 1):
            xl_local[ji(k), ip_idx] = i3[ji(k)]

    # Copy results into xl output array
    for k in range(-mu, mu + 1):
        for p in range(np_):
            xl[ji(k), p] = xl_local[ji(k), p]

    nt = snt
