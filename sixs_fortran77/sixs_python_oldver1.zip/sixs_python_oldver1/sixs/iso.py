"""
iso.py
------
Translated from ISO.f

Successive Orders of Scattering (ISO) — computes diffuse transmittances
via iterative convergence of multiple-scattering orders.
"""

import math
import numpy as np

from .commons   import delta_sigma, trunc, ier as ier_common
from .scattering import discre


def iso(tamoy, trmoy, pizmoy, tamoyp, trmoyp, palt, nt, mu, rm, gb):
    """
    Compute up/down diffuse transmittances and spherical-albedo factor
    via successive orders of scattering.

    Parameters
    ----------
    tamoy, trmoy, pizmoy : float – aerosol OD, Rayleigh OD, SSA
    tamoyp, trmoyp       : float – ODs above the plane level
    palt                 : float – plane altitude (km; >900 → satellite)
    nt                   : int   – number of layers
    mu                   : int   – number of Gauss half-angles
    rm                   : array – Gauss nodes, indexed -mu..+mu
    gb                   : array – Gauss weights, indexed -mu..+mu

    Returns
    -------
    xf : dict with keys -1, 0, 1
         xf[-1] = upward diffuse transmittance at plane/TOA
         xf[0]  = 2 × spherical-albedo integral
         xf[1]  = downward diffuse transmittance at surface
    """
    from .kernel import kernel_func   # deferred to avoid circularity

    delta  = delta_sigma.delta
    pha    = trunc.pha
    betal  = trunc.betal
    _ier   = ier_common

    snt    = nt
    accu   = 1.0e-20
    accu2  = 1.0e-3
    hr     = 8.0

    ta  = tamoy
    tr  = trmoy
    piz = pizmoy
    trp = trmoy  - trmoyp
    tap = tamoy  - tamoyp

    iplane = 0

    # Scale height for aerosols
    if palt <= 900.0 and palt > 0.0:
        ha  = -palt / math.log(tap / ta) if tap > 1.0e-3 else 2.0
        ntp = nt - 1
    else:
        ha  = 2.0
        ntp = nt

    # Layer optical depth boundaries h(0..nt), fractional compositions
    h    = [0.0] * (nt + 1)
    xdel = [0.0] * (nt + 1)
    ydel = [0.0] * (nt + 1)
    altc = [0.0] * (nt + 1)

    if ta <= accu2 and tr > ta:
        for j in range(ntp + 1):
            h[j]    = j * tr / ntp if ntp > 0 else 0.0
            ydel[j] = 1.0
            xdel[j] = 0.0
    elif tr <= accu2 and ta > tr:
        for j in range(ntp + 1):
            h[j]    = j * ta / ntp if ntp > 0 else 0.0
            ydel[j] = 0.0
            xdel[j] = piz
    else:
        ydel[0] = 1.0; xdel[0] = 0.0; h[0] = 0.0; altc[0] = 300.0
        zx = 300.0; iplane = 0
        for it in range(ntp + 1):
            if it == 0:
                yy = 0.0; dd = 0.0
            else:
                yy = h[it - 1]; dd = ydel[it - 1]
            ppp2 = 300.0; ppp1 = 0.0
            zx = discre(ta, ha, tr, hr, it, ntp, yy, dd, ppp2, ppp1)
            if _ier.ier:
                return {-1: 0.0, 0: 0.0, 1: 0.0}
            xxx = -zx / ha
            ca  = ta * math.exp(xxx) if xxx >= -18.0 else 0.0
            cr  = tr * math.exp(-zx / hr)
            h[it]    = cr + ca
            altc[it] = zx
            cr2 = cr / hr; ca2 = ca / ha
            ratio    = cr2 / (cr2 + ca2)
            xdel[it] = (1.0 - ratio) * piz
            ydel[it] = ratio

    # Insert plane layer if needed
    if ntp == nt - 1:
        taup   = tap + trp
        iplane = -1
        for i in range(ntp + 1):
            if taup >= h[i]:
                iplane = i
        th  = 0.005
        xt1 = abs(h[iplane] - taup)
        xt2 = abs(h[iplane + 1] - taup) if iplane + 1 <= nt else 1e9
        if xt1 > th and xt2 > th:
            for i in range(nt, iplane, -1):
                xdel[i] = xdel[i - 1]
                ydel[i] = ydel[i - 1]
                h[i]    = h[i - 1]
                altc[i] = altc[i - 1]
        else:
            nt_local = ntp
            if xt2 < xt1:
                iplane += 1
        h[iplane] = taup
        if tr > accu2 and ta > accu2:
            ca = ta * math.exp(-palt / ha)
            cr = tr * math.exp(-palt / hr)
            cr /= hr; ca /= ha
            ratio = cr / (cr + ca)
            xdel[iplane] = (1.0 - ratio) * piz
            ydel[iplane] = ratio
            altc[iplane] = palt
        elif tr > accu2:
            ydel[iplane] = 1.0; xdel[iplane] = 0.0; altc[iplane] = palt
        else:
            ydel[iplane] = 0.0; xdel[iplane] = piz; altc[iplane] = palt

    # Rayleigh phase function coefficients
    aaaa  = delta / (2.0 - delta)
    ron   = (1.0 - aaaa) / (1.0 + 2.0 * aaaa)
    beta0 = 1.0
    beta2 = 0.5 * ron

    ig = 1
    tavion0 = tavion1 = tavion2 = tavion = 0.0

    # Allocate arrays  (index range -mu..+mu and 0..nt)
    size_j = 2 * mu + 1   # indices 0..(2*mu) represent -mu..+mu
    def ji(k):            # map signed index k to 0-based
        return k + mu

    i1  = np.zeros((nt + 1, size_j))
    i2  = np.zeros((nt + 1, size_j))
    i3  = np.zeros(size_j)
    inm1 = np.zeros(size_j)
    inm2 = np.zeros(size_j)
    _in  = np.zeros(size_j)

    # Kernel
    xpl, psl, bp = kernel_func(0, mu, rm)

    # Primary upward radiation
    for k in range(1, mu + 1):
        i1[nt, ji(k)] = 1.0
        zi1 = 1.0
        yy  = rm[ji(k)]
        for i in range(nt - 1, -1, -1):
            i1[i, ji(k)] = math.exp(-(ta + tr - h[i]) / yy)

    # Primary downward radiation (zero at TOA)
    for k in range(-mu, 0):
        for i in range(nt + 1):
            i1[i, ji(k)] = 0.0

    # Initialise scattering order accumulators
    for k in range(-mu, mu + 1):
        idx = nt if k < 0 else 0
        inm1[ji(k)]  = i1[idx, ji(k)]
        inm2[ji(k)]  = i1[idx, ji(k)]
        i3[ji(k)]    = i1[idx, ji(k)]

    tavion   = i1[iplane if iplane >= 0 else 0, ji(mu)]
    tavion2  = tavion

    # Successive orders loop
    while True:
        ig += 1

        # Source function at each level
        for k in range(1, mu + 1):
            xpk = xpl[ji(k)]
            ypk = xpl[ji(-k)]
            for i in range(nt + 1):
                ii1 = 0.0; ii2 = 0.0
                x   = xdel[i]; y = ydel[i]
                for j in range(1, mu + 1):
                    xpj  = xpl[ji(j)]
                    z    = gb[ji(j)]
                    xi1  = i1[i, ji(j)]
                    xi2  = i1[i, ji(-j)]
                    bpjk  = bp[j, ji(k)]  * x + y * (beta0 + beta2 * xpj * xpk)
                    bpjmk = bp[j, ji(-k)] * x + y * (beta0 + beta2 * xpj * ypk)
                    ii2  += z * (xi1 * bpjk  + xi2 * bpjmk)
                    ii1  += z * (xi1 * bpjmk + xi2 * bpjk)
                i2[i, ji(k)]  = ii2
                i2[i, ji(-k)] = ii1

        # Upward integration
        for k in range(1, mu + 1):
            i1[nt, ji(k)] = 0.0
            zi1 = 0.0
            yy  = rm[ji(k)]
            for i in range(nt - 1, -1, -1):
                jj = i + 1
                f  = h[jj] - h[i]
                a  = (i2[jj, ji(k)] - i2[i, ji(k)]) / f
                b  = i2[i, ji(k)] - a * h[i]
                c  = math.exp(-f / yy)
                d  = 1.0 - c
                xx = h[i] - h[jj] * c
                zi1 = c * zi1 + (d * (b + a * yy) + a * xx) * 0.5
                i1[i, ji(k)] = zi1

        # Downward integration
        for k in range(-mu, 0):
            i1[0, ji(k)] = 0.0
            zi1 = 0.0
            yy  = rm[ji(k)]
            for i in range(1, nt + 1):
                jj = i - 1
                f  = h[i] - h[jj]
                c  = math.exp(f / yy)
                d  = 1.0 - c
                a  = (i2[i, ji(k)] - i2[jj, ji(k)]) / f
                b  = i2[i, ji(k)] - a * h[i]
                xx = h[i] - h[jj] * c
                zi1 = c * zi1 + (d * (b + a * yy) + a * xx) * 0.5
                i1[i, ji(k)] = zi1

        for k in range(-mu, mu + 1):
            idx = nt if k < 0 else 0
            _in[ji(k)] = i1[idx, ji(k)]

        tavion0 = i1[iplane if iplane >= 0 else 0, ji(mu)]

        # Convergence test
        if ig > 2:
            z = 0.0
            a1 = tavion2; d1 = tavion1; g1 = tavion0
            if a1 >= accu and d1 >= accu and tavion >= accu:
                y  = abs(((g1/d1 - d1/a1) / ((1.0 - g1/d1)**2)) * (g1 / tavion))
                z  = max(y, z)
            for l in range(-mu, mu + 1):
                if l == 0: continue
                a1 = inm2[ji(l)]; d1 = inm1[ji(l)]; g1 = _in[ji(l)]
                if a1 == 0.0 or d1 == 0.0 or i3[ji(l)] == 0.0: continue
                y = abs(((g1/d1 - d1/a1) / ((1.0 - g1/d1)**2)) * (g1 / i3[ji(l)]))
                z = max(y, z)

            if z < 0.0001:
                # Geometric series extrapolation
                for l in range(-mu, mu + 1):
                    if l == 0: continue
                    d1 = inm1[ji(l)]; g1 = _in[ji(l)]
                    if d1 == 0.0: continue
                    y1 = 1.0 - g1 / d1
                    g1 = g1 / y1
                    i3[ji(l)] += g1
                d1 = tavion1; g1 = tavion0
                if d1 >= accu and abs(g1 - d1) >= accu:
                    y1 = 1.0 - g1 / d1
                    g1 = g1 / y1
                tavion += g1
                break

            inm2[:] = inm1
            tavion2  = tavion1

        inm1[:] = _in
        tavion1  = tavion0
        i3 += _in
        tavion += tavion0

        # Stop if contribution < 0.001%
        z = 0.0
        for l in range(-mu, mu + 1):
            if i3[ji(l)] != 0.0:
                z = max(z, abs(_in[ji(l)] / i3[ji(l)]))
        if z < 0.00001:
            break
        if ig >= 20:
            break

    xf = {
        1:  i3[ji(mu)],
        -1: tavion,
        0:  sum(rm[ji(k)] * gb[ji(k)] * i3[ji(-k)] for k in range(1, mu + 1)),
    }
    nt = snt   # restore nt (local — no effect on caller in Python)
    return xf
