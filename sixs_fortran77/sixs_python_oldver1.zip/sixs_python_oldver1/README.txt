Here's your download — a 202 KB zip containing the complete Python package. Inside you'll find:

```
sixs_python/
├── setup.py
└── sixs/
    ├── __init__.py          ← package entry point
    ├── __main__.py          ← python -m sixs
    ├── commons.py           ← all COMMON blocks
    ├── gauss.py             ← Gauss-Legendre quadrature
    ├── utils.py             ← VARSOL, ODRAYL, CSALBR, SOLIRR, PRINT_ERROR
    ├── possol.py            ← solar position
    ├── atm_profiles.py      ← 6 McClatchey profiles
    ├── pressure.py          ← PRESSURE, PRESPLANE
    ├── oda550.py            ← aerosol OD at 550nm
    ├── gas_tables.py        ← 33 absorption coefficient tables
    ├── abstra.py            ← gas transmittances
    ├── aerosol_components.py← DUST, WATE, OCEA, SOOT
    ├── aeroso.py            ← aerosol optical properties
    ├── interp.py            ← splines, INTERP, EQUIVWL, TRUNCA
    ├── kernel.py            ← phase function kernel
    ├── iso.py               ← successive orders of scattering
    ├── os_module.py         ← full SOS radiance field
    ├── scattering.py        ← DISCRE, SCATRA, DISCOM
    ├── atmref.py            ← CHAND, ATMREF
    ├── specinterp.py        ← SPECINTERP, ENVIRO
    ├── sensors.py           ← METEO, GOES, AVHRR, HRV, TM, MSS, MAS, MODIS, POLDER
    ├── surface_reflectance.py← VEGETA, SAND, CLEARW, LAKEW
    ├── brdf_models.py       ← all BRDF models
    ├── geometry.py          ← POSGE, POSGW, POSMTO, POSNOA, POSLAN, POSSPO
    └── sixs_main.py         ← main.f (the full program)
```

**To install and use:**
```bash
cd sixs_python
pip install -e .

# Command-line (same interface as the original Fortran binary):
python -m sixs < your_input.txt

# Programmatic:
from sixs.sixs_main import run
import io
results = run(io.StringIO(input_text))
print(results['apparent_reflectance'])
```

Note that a few files from the original (AKTOOL/Kuusk canopy model, the Mie scattering solver, OCEABRDF/OCEATOOLS, IAPIALBE/IAPIBRDF) were not fully translated as they are large self-contained scientific sub-models — stubs are present so the package loads cleanly, but those specific BRDF options (ibrdf=6,7,9) will need those modules completed if you use them.