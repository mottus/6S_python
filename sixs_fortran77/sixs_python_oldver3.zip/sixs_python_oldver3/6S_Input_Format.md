# 6S Python — Input File Format Reference

## Overview

The input is a plain-text stream read line by line. Tokens are whitespace-separated;
multiple values on one line or spread across several lines are both accepted.
Lines beginning with `!` or `c` are treated as comments. A minimal run requires
nine sections in the order shown below.

All **angles** are in **degrees**, all **wavelengths** in **micrometres (µm)**.
The model is valid from **0.25 to 4.0 µm**.

---

## Section 1 — Geometry (`igeom`)

**Line:** `igeom`

| `igeom` | Meaning | Next line(s) |
|---------|---------|-------------|
| `0` | User-defined angles | `asol  phi0  avis  phiv  month  day` |
| `1` | Meteosat | `month  day  hour  n_col  n_line` |
| `2` | GOES East | `month  day  hour  n_col  n_line` |
| `3` | GOES West | `month  day  hour  n_col  n_line` |
| `4` | AVHRR PM NOAA | `month  day  hour  n_col  lon_node  hour_node` |
| `5` | AVHRR AM NOAA | `month  day  hour  n_col  lon_node  hour_node` |
| `6` | HRV (SPOT) | `month  day  hour  longitude  latitude` |
| `7` | TM (Landsat) | `month  day  hour  longitude  latitude` |

**User-defined parameters (`igeom = 0`):**

| Parameter | Range | Description |
|-----------|-------|-------------|
| `asol` | 0–90° | Solar zenith angle |
| `phi0` | 0–360° | Solar azimuth angle |
| `avis` | 0–90° | Sensor zenith angle |
| `phiv` | 0–360° | Sensor azimuth angle |
| `month` | 1–12 | Month |
| `day` | 1–31 | Day |

The relative azimuth used internally is `phi = |phiv − phi0|`. At `phi = 0°` the
sensor looks in the forward-scatter direction; at `phi = 180°` it looks away from
the sun (backscatter). For nadir viewing (`avis = 0`), `phiv` has no effect.

---

## Section 2 — Atmospheric model (`idatm`)

**Line:** `idatm`

| `idatm` | Profile | Extra input |
|---------|---------|------------|
| `0` | No gaseous absorption | — |
| `1` | Tropical | — |
| `2` | Mid-latitude summer | — |
| `3` | Mid-latitude winter | — |
| `4` | Subarctic summer | — |
| `5` | Subarctic winter | — |
| `6` | US Standard 1962 | — |
| `7` | User radiosonde (34 levels) | 34 lines of `z(km) p(mb) T(K) ρ_H₂O(g/m³) ρ_O₃(g/m³)` |
| `8` | US62 profile with user column amounts | `uw(g/cm²)  uo3(cm-atm)` |

---

## Section 3 — Aerosol model type (`iaer`)

**Line:** `iaer`  followed by additional data as described.

### Standard models — no extra input

| `iaer` | Model |
|--------|-------|
| `0` | No aerosols |
| `1` | Continental (SRA mix: 70 % dust, 29 % water-soluble, 1 % soot) |
| `2` | Maritime (SRA mix: 5 % water-soluble, 95 % oceanic) |
| `3` | Urban (SRA mix: 17 % dust, 61 % water-soluble, 22 % soot) |
| `5` | Background desert (BDM) |
| `6` | Biomass burning (BBM) |
| `7` | Stratospheric (STM) |

### User-defined mixture — `iaer = 4`

Next line: `c1  c2  c3  c4`  
Volume fractions (0–1, must sum to 1) of dust-like / water-soluble / oceanic / soot.

### Mie size-distribution models — `iaer = 8, 9, 10, 11`

All Mie models require the **real and imaginary refractive index at 10 wavelengths**:
0.400, 0.488, 0.515, 0.550, 0.633, 0.694, 0.860, 1.536, 2.250, 3.750 µm.

After the distribution parameters, all Mie models need:

```
iaerp          ← 0 = discard Mie result; 1 = save to FILE.mie (then enter FILE name)
```

**`iaer = 8` — Multimodal log-normal (up to 4 modes)**
```
rmin  rmax  icp                  ← radius limits (µm) and number of modes
x1(1)  x2(1)  cij(1)             ← mode 1: median radius (µm), geom. std dev, fraction
nr_1..10                         ← real refractive index at 10 wavelengths
ni_1..10                         ← imaginary refractive index
... repeat for each mode ...
iaerp
```

**`iaer = 9` — Modified gamma distribution**
```
rmin  rmax
x1  x2  x3                       ← α, b, γ  in  n(r) ∝ (r/r₀)^α exp(−b·(r/r₀)^γ)
nr_1..10
ni_1..10
iaerp
```

**`iaer = 10` — Junge power-law distribution**
```
rmin  rmax
x1                                ← exponent ν  (dn/dr ∝ r^−ν, typically ν ≈ 3–4)
nr_1..10
ni_1..10
iaerp
```

**`iaer = 11` — Sun photometer (dV/d(log r) measured)**
```
irsunph                           ← number of data points (max 50)
r_1   dVdlogr_1                   ← radius (µm) and volume distribution value
...
nr_1..10
ni_1..10
iaerp
```

### Pre-computed file — `iaer = 12`

Next line: path to a previously saved `.mie` file.

---

## Section 4 — Aerosol concentration

**Line:** `v`  (meteorological visibility in km)

| Entry | Meaning |
|-------|---------|
| `v > 0` | Visibility in km; AOT computed from standard profile |
| `v = 0` | Next line: `taer55` — aerosol optical depth at 550 nm |
| `v = −1` | No aerosols (use with `iaer = 0`) |

---

## Section 5 — Target altitude (`xps`)

**Line:** `xps`

| Value | Meaning |
|-------|---------|
| `xps ≥ 0` | Target at sea level |
| `xps < 0` | Target altitude in km, e.g. `−1.5` for 1.5 km above sea level |

---

## Section 6 — Sensor altitude (`xpp`)

**Line:** `xpp`

| Value | Meaning |
|-------|---------|
| `−1000` | Satellite (top of atmosphere) |
| `0` | Ground-level sensor |
| `−100 < xpp < 0` | Aircraft at altitude `|xpp|` km above target |

**For aircraft only**, two additional lines follow immediately after `xpp`:

```
puw  puo3          ← water vapour (g/cm²) and ozone (cm-atm) between aircraft and surface;
                      enter negative values to interpolate from the US62 profile
taerp              ← aerosol OD at 550 nm between aircraft and surface;
                      enter negative to compute from a 2 km exponential profile
```

---

## Section 7 — Spectral band (`iwave`)

**Line:** `iwave`

### User-defined conditions

| `iwave` | Meaning | Extra input |
|---------|---------|-------------|
| `−2` | Flat filter, with per-wavelength output | `wlinf  wlsup` |
| `−1` | Monochromatic | `wl` (single wavelength) |
| `0` | Flat filter over band | `wlinf  wlsup` |
| `1` | User filter function | `wlinf  wlsup`, then S(λ) values at 0.0025 µm steps |

### Pre-defined satellite bands

| `iwave` | Band |
|---------|------|
| 2 | Meteosat VIS (0.350–1.110 µm) |
| 3 | GOES East VIS (0.490–0.900 µm) |
| 4 | GOES West VIS (0.490–0.900 µm) |
| 5–6 | AVHRR NOAA-6 bands 1–2 |
| 7–8 | AVHRR NOAA-7 bands 1–2 |
| 9–10 | AVHRR NOAA-8 bands 1–2 |
| 11–12 | AVHRR NOAA-9 bands 1–2 |
| 13–14 | AVHRR NOAA-10 bands 1–2 |
| 15–16 | AVHRR NOAA-11 bands 1–2 |
| 17–20 | HRV1 SPOT-1 (green, red, NIR, pan) |
| 21–24 | HRV2 SPOT-1 (green, red, NIR, pan) |
| 25–30 | TM Landsat-5 bands 1–5, 7 |
| 31–34 | MSS Landsat-5 bands 1–4 |
| 35–41 | MAS (ER-2) bands 1–7 |
| 42–48 | MODIS bands 1–7 |
| 49–50 | AVHRR NOAA-12 bands 1–2 |
| 51–52 | AVHRR NOAA-14 bands 1–2 |
| 53–60 | POLDER bands 1–8 |

---

## Section 8 — Ground reflectance

### 8a — Spatial homogeneity (`inhomo`)

**Line:** `inhomo`

| `inhomo` | Meaning | Extra input |
|----------|---------|-------------|
| `0` | Uniform surface | — |
| `1` | Circular target of radius `rad` km inside a background | `igrou1  igrou2  rad` |

For `inhomo = 1`, `igrou1` is the target reflectance code and `igrou2` is the background
code (both use the same codes as `igroun` below).

### 8b — Directionality (`idirec`)

**Line:** `idirec`

| `idirec` | Meaning | Next parameter |
|----------|---------|----------------|
| `0` | Lambertian | `igroun` |
| `1` | Bidirectional (BRDF) | `ibrdf` |

### 8c-L — Lambertian surface type (`igroun`)

**Line:** `igroun`

| Code | Type | Extra input |
|------|------|-------------|
| `0` | Constant reflectance | `ro` (single value 0–1) |
| `−1` | User spectrum | Reflectance values at 0.0025 µm steps from `wlinf` to `wlsup` |
| `1` | Green vegetation | — |
| `2` | Clear water | — |
| `3` | Sand | — |
| `4` | Lake water | — |

### 8c-B — BRDF model (`ibrdf`)

**Line:** `ibrdf`

| `ibrdf` | Model | Parameters |
|---------|-------|-----------|
| `0` | Measured angular grid | 10×13 BRDF values for sun at θ_sun; 10×13 for sun at θ_view; then albedo and rodir |
| `1` | Hapke | `om  af  s0  h` |
| `2` | Verstraete–Pinty | 3 lines: options / structural / optical |
| `3` | Roujean | `k0  k1  k2` |
| `4` | Walthall | `a  ap  b  c` |
| `5` | Minnaert | `par1(ρ₀)  par2(k)` |
| `6` | Ocean (Cox-Munk + Morel) | `pws  phi_wind  xsal  pcl` |
| `7` | Iaquinta–Pinty canopy | 3 lines (see below) |
| `8` | Rahman | `rho0  af  xk` |
| `9` | Kuusk MSRM canopy | 2 lines (see below) |

**Hapke parameters (`ibrdf = 1`):**

| Parameter | Meaning |
|-----------|---------|
| `om` | Single-scattering albedo |
| `af` | Asymmetry parameter for the phase function |
| `s0` | Amplitude of the hot-spot |
| `h` | Width of the hot-spot |

**Roujean parameters (`ibrdf = 3`):**

| Parameter | Meaning |
|-----------|---------|
| `k0` | Isotropic term |
| `k1` | Volumetric (Ross) kernel coefficient |
| `k2` | Geometric (Li) kernel coefficient |

**Walthall parameters (`ibrdf = 4`):**

| Parameter | Meaning |
|-----------|---------|
| `a` | Coefficient of θ_sun × θ_view |
| `ap` | Coefficient of (θ_sun² + θ_view²) |
| `b` | Coefficient of θ_sun × θ_view × cos φ |
| `c` | Nadir albedo |

**Minnaert parameters (`ibrdf = 5`):**

| Parameter | Meaning |
|-----------|---------|
| `par1` | Nadir reflectance ρ₀ |
| `par2` | Minnaert exponent k |

**Ocean parameters (`ibrdf = 6`):**

| Parameter | Unit | Meaning |
|-----------|------|---------|
| `pws` | m/s | Wind speed |
| `phi_wind` | degrees | Azimuth of wind direction |
| `xsal` | ppt | Salinity (enter ≤ 0 for default 34.3 ppt) |
| `pcl` | mg/m³ | Phytoplankton pigment concentration |

**Iaquinta–Pinty canopy parameters (`ibrdf = 7`):**

```
ild  ihs                 ← leaf angle distribution (1–5), hot-spot flag (0/1)
LAI  c                   ← leaf area index, hot-spot parameter 2rΛ (0–2)
Rl  Tl  Rs               ← leaf reflectance, leaf transmittance, soil albedo
```

`ild` options: 1 = planophile, 2 = erectophile, 3 = plagiophile, 4 = extremophile, 5 = uniform.
Constraints: 0 ≤ Rl, Tl ≤ 0.99, Rl + Tl < 0.99; 1 ≤ LAI ≤ 15.

**Rahman parameters (`ibrdf = 8`):**

| Parameter | Meaning |
|-----------|---------|
| `rho0` | Nadir reflectance |
| `af` | Asymmetry factor |
| `xk` | Minnaert exponent |

**Kuusk MSRM canopy parameters (`ibrdf = 9`):**

```
ee  thm  ul  sl  rsl1        ← clumping ε, mean leaf angle (°), LAI, leaf size, soil brightness
rnc  cab  cw  vai            ← refractive index coeff (~1.0), chl a+b (µg/cm²), water (cm), N layers
```

| Parameter | Unit | Description |
|-----------|------|-------------|
| `ee` | — | Clumping parameter ε (0 = random, 1 = fully clumped) |
| `thm` | degrees | Mean leaf inclination angle |
| `ul` | m²/m² | Leaf area index |
| `sl` | — | Relative leaf size parameter |
| `rsl1` | — | Soil brightness |
| `rnc` | — | Leaf refractive index coefficient (typically ≈ 1.0) |
| `cab` | µg/cm² | Chlorophyll a+b content |
| `cw` | cm | Equivalent leaf water thickness |
| `vai` | — | Number of PROSPECT leaf layers N |

Valid wavelength range for the Kuusk model: **0.404–2.500 µm**.

---

## Section 9 — Atmospheric correction (`rapp`)

**Line:** `rapp`

| Value | Meaning |
|-------|---------|
| `rapp < −1` | Forward simulation only; no retrieval |
| `−1 ≤ rapp < 0` | Retrieve surface reflectance from apparent reflectance `|rapp|` |
| `rapp > 0` | Retrieve surface reflectance from measured radiance `rapp` (W/m²/sr/µm) |

---

## Complete example — minimal satellite run

```
0                            ← igeom: user-defined angles
30.0 0.0 0.0 180.0 7 1      ← asol phi0 avis phiv month day
2                            ← idatm: mid-latitude summer
1                            ← iaer: continental aerosol
23.0                         ← visibility = 23 km
0.0                          ← xps: target at sea level
-1000                        ← xpp: satellite sensor
5                            ← iwave: AVHRR NOAA-6 band 1 (0.55–0.75 µm)
0                            ← inhomo: uniform surface
0                            ← idirec: Lambertian
3                            ← igroun: sand spectrum
-2.0                         ← rapp: forward simulation (no retrieval)
```

---

## Complete example — Mie aerosol and Kuusk canopy BRDF, satellite NIR

```
0
45.0 180.0 10.0 0.0 8 15    ← SZA 45°, view nadir, August 15
2                            ← mid-latitude summer
8                            ← iaer: log-normal Mie distribution
0.005 5.0 1                  ← rmin rmax icp (1 mode)
0.12 2.0 1.0                 ← median radius (µm), geometric std dev, fraction
1.53 1.53 1.53 1.53 1.53 1.53 1.52 1.40 1.22 1.27   ← nr at 10 wavelengths
0.008 0.008 0.007 0.006 0.005 0.005 0.003 0.001 0.008 0.008  ← ni
0                            ← iaerp: don't save Mie results
23.0                         ← visibility = 23 km  (AOT computed)
0.0                          ← xps: target at sea level
-1000                        ← xpp: satellite
28                           ← iwave: TM Landsat-5 band 4 NIR (0.73–0.95 µm)
0                            ← inhomo: uniform
1                            ← idirec: BRDF
9                            ← ibrdf: Kuusk MSRM canopy model
0.7 57.0 3.0 0.05 0.10      ← ee thm(°) LAI sl rsl1
1.0 40.0 0.02 1.5            ← rnc  cab(µg/cm²)  cw(cm)  N
-2.0                         ← rapp: forward simulation
```

Expected output line:
```
  mm   dd      h_s      H2O       O3      aot          dir          dif          seb
   8   15   45.000   0.0000   0.0000   0.2347   5.9932e+01   1.8858e+01   1.2296e+02
```
with `apparent_reflectance ≈ 0.38` for green vegetation NIR.

---

## Validity limits

| Parameter | Limit |
|-----------|-------|
| Wavelength range | 0.25–4.0 µm |
| Minimum visibility | 5 km (aerosol models unreliable below this) |
| Mie wavelength range (Kuusk) | 0.404–2.500 µm |
| Iaquinta–Pinty LAI | 1–15 |
| Kuusk refractive index coeff | typically 0.9–1.1 |
